# OpenClaw AI Agent Sandbox Platform

A production-grade AI agent execution platform with real WebSocket-connected agents, multi-provider AI routing, persistent memory, and Cloudflare Workers deployment.

## Agent Types

| Agent | Color | Default Model | Max Tokens | Max Parallel | Best For |
|-------|-------|--------------|-----------|-------------|---------|
| **OpenClaw** | 🟢 Green | `gpt-5.2` | 4,096 | 20 | Full-featured tasks, workflows, research |
| **NanoClaw** | 🔵 Cyan | `gpt-5-mini` | 1,024 | 10 | Ultra-fast Q&A, quick tasks, low cost |
| **NemoClaw** | 🟣 Purple | `o4-mini` | 16,384 | 5 | Deep reasoning, complex analysis, research |

All three agents: **zero simulation** — every command routes through real AI via WebSocket.

---

## Architecture

```
Browser (xterm.js)
    │ WebSocket JSON messages
    ▼
┌─────────────────────────────────────────────────────────────┐
│              Node.js API Server (local dev)                 │
│  wsServer.ts routes by agentType:                           │
│    OpenClawAgent  →  RealAgentSession.ts (full, 4096 tok)  │
│    NanoClawAgent  →  NanoClawSession.ts  (fast, 1024 tok)  │
│    NemoClawAgent  →  NemoClawSession.ts  (deep, 16384 tok) │
│           ↓                                                 │
│     providerRouter.ts → 11 AI providers                    │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│           Cloudflare Workers (production)                   │
│  routeAgentRequest() routes /agents/:class/:id →           │
│    OpenClawAgent DO  (SQLite + Workers AI + V8 isolates)   │
│    NanoClawAgent DO  (SQLite + Workers AI, fast model)     │
│    NemoClawAgent DO  (SQLite + Workers AI, reasoning)      │
└─────────────────────────────────────────────────────────────┘
```

## Project Structure

```
/
├── artifacts/
│   ├── agent-sandbox/              # React + Vite frontend (xterm.js)
│   │   └── src/
│   │       ├── components/
│   │       │   ├── XTerminal.tsx          # Real xterm.js terminal
│   │       │   ├── Terminal.tsx           # Terminal header + wrapper
│   │       │   └── layout/Sidebar.tsx     # Session list + agent type picker
│   │       ├── hooks/
│   │       │   └── use-agent-websocket.ts # WS hook routing 3 agent classes
│   │       └── pages/
│   │           ├── Dashboard.tsx
│   │           ├── SessionView.tsx        # Agent terminal page
│   │           ├── Workflows.tsx          # 12 agentic workflows
│   │           ├── Research.tsx           # AutoResearch loop UI
│   │           └── Settings.tsx           # AI provider config
│   │
│   └── api-server/                 # Node.js + Express WebSocket API
│       └── src/
│           ├── agent/
│           │   ├── RealAgentSession.ts    # OpenClaw (full featured)
│           │   ├── NanoClawSession.ts     # NanoClaw (ultra-fast)
│           │   ├── NemoClawSession.ts     # NemoClaw (deep reasoning)
│           │   ├── ResearchLoop.ts        # Autonomous research engine
│           │   └── wsServer.ts            # Multi-agent WS router
│           ├── lib/
│           │   ├── providerRouter.ts      # 11-provider AI routing + streaming
│           │   ├── providerConfig.ts      # Provider API key config
│           │   ├── liveModels.ts          # Real-time model fetching
│           │   ├── usageTracker.ts        # Token + cost tracking (PostgreSQL)
│           │   └── workflows.ts           # 12 workflow definitions
│           └── routes/
│               ├── sessions.ts            # Session CRUD + execute + tasks
│               ├── providers.ts           # Provider info + live models
│               ├── research.ts            # AutoResearch API
│               └── usage.ts              # Usage analytics
│
├── cloudflare-worker/              # Production Cloudflare Workers backend
│   ├── src/
│   │   ├── agent.ts               # OpenClawAgent + NanoClawAgent + NemoClawAgent DOs
│   │   ├── index.ts               # Hono API + routeAgentRequest()
│   │   ├── billing.ts             # Stripe subscription management
│   │   ├── models.ts              # Workers AI model catalog (100+ models)
│   │   └── types/index.ts         # TypeScript: Env bindings for all 3 DOs
│   ├── migrations/
│   │   └── 0001_initial.sql       # D1 schema (users, sessions, billing)
│   └── wrangler.jsonc             # CF config: AI, 3x DO, D1, LOADER, observability
│
└── lib/
    └── db/                         # Drizzle ORM + PostgreSQL
        └── src/schema/sessions.ts  # Sessions table (with agentType column)
```

---

## Quick Start — Local Development

### Prerequisites
- Node.js 18+, pnpm 8+, PostgreSQL
- No API keys required — OpenAI works via Replit AI Integration

```bash
# 1. Install dependencies
pnpm install

# 2. Sync database schema (adds agentType column)
cd lib/db && pnpm run push && cd ../..

# 3. Start API server (WebSocket + REST on port 8080)
pnpm --filter @workspace/api-server run dev

# 4. Start frontend (auto-port, proxied at /)
pnpm --filter @workspace/agent-sandbox run dev
```

Open http://localhost/ → click **NEW_SESSION** → pick an agent type → start typing.

### Optional: Additional AI Providers

```bash
# Set via Replit Secrets (Settings → Secrets) or .env file:
ANTHROPIC_API_KEY=sk-ant-...      # Claude models
GROQ_API_KEY=gsk_...              # Groq (free, fast)
TOGETHER_API_KEY=...              # Together AI
OPENROUTER_API_KEY=sk-or-...      # OpenRouter (100+ models)
MISTRAL_API_KEY=...               # Mistral
GEMINI_API_KEY=...                # Google Gemini
COHERE_API_KEY=...                # Cohere
PERPLEXITY_API_KEY=...            # Perplexity
# For local models (no key needed):
# Ollama:    run `ollama serve` locally, use models like `ollama/llama3`
# LM Studio: run LM Studio locally, use models like `lmstudio/mistral`
```

---

## Cloudflare Workers Deployment

### One-Time Setup

```bash
cd cloudflare-worker

# Install Wrangler
npm install -g wrangler@latest
wrangler login

# Install worker dependencies
npm install

# Create D1 database
wrangler d1 create openclaw_users
# → Copy the database_id into wrangler.jsonc → d1_databases[0].database_id

# Run D1 migrations
npm run d1:migrate

# Set secrets
wrangler secret put STRIPE_SECRET          # From Stripe Dashboard
wrangler secret put STRIPE_WEBHOOK_SECRET  # From Stripe Webhooks

# Optional
wrangler secret put ANTHROPIC_API_KEY
```

### Deploy

```bash
npm run deploy
# Deploys: OpenClawAgent DO + NanoClawAgent DO + NemoClawAgent DO
# Workers AI runs on Cloudflare's infrastructure — no API key needed
```

### Connect Frontend to Cloudflare

In Replit Secrets (or .env):
```
VITE_CLOUDFLARE_WORKER_URL=https://openclaw-platform.<your-account>.workers.dev
```

The WS hook automatically uses the correct DO class per session's agentType.

### Production WebSocket URLs

```
wss://openclaw-platform.your-account.workers.dev/agents/OpenClawAgent/<sessionId>
wss://openclaw-platform.your-account.workers.dev/agents/NanoClawAgent/<sessionId>
wss://openclaw-platform.your-account.workers.dev/agents/NemoClawAgent/<sessionId>
```

---

## REST API Reference

Base: `/api`

### Sessions

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/sessions` | List all sessions |
| `POST` | `/sessions` | Create session (`{ name, model?, agentType? }`) |
| `GET` | `/sessions/:id` | Get session |
| `DELETE` | `/sessions/:id` | Terminate session |
| `POST` | `/sessions/:id/execute` | Execute command (HTTP fallback, real AI) |
| `POST` | `/sessions/:id/tasks` | Background task (real AI, stores in DB) |
| `GET` | `/sessions/:id/tasks` | List tasks |
| `GET` | `/sessions/:id/history` | Command history |

**Session `agentType` values:** `"openclaw"` · `"nanoclaw"` · `"nemoclaw"`

### Providers

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/providers` | List all 11 providers |
| `GET` | `/providers/:id/models` | Live model list for provider |

### Usage

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/usage` | Token + cost summary |
| `GET` | `/usage/by-provider` | Usage grouped by provider |

### Research

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/research/runs` | Start AutoResearch loop |
| `GET` | `/research/runs` | List runs |
| `GET` | `/research/runs/:id` | Run + experiments detail |

---

## Agent Commands

All three agents support the same commands (with limits per type):

```bash
# === Execution ===
<any text>               Execute in isolate via real AI
chat <message>           Streaming conversation with history
parallel <N> <task>      N concurrent real AI calls (max: 20/10/5)
workflow run <id>        Run agentic workflow step-by-step
workflow list            List 12 available workflows

# === Memory (persists in-session) ===
memory                   Show all memory files
remember <key>: <value>  Store to memory

# === Model ===
model <name>             Switch AI model live
                         e.g. model gpt-5.2
                              model groq/llama-3.3-70b-versatile
                              model anthropic/claude-3-7-sonnet
                              model ollama/llama3

# === System ===
status                   Agent status + real session data
whoami                   Agent identity + capabilities
version                  Platform version
history                  Recent conversation (last 10)
clear                    Clear conversation history
ping <host>              Always: network isolated (globalOutbound: null)
```

**NemoClaw only:**
```bash
thinking on              Enable chain-of-thought reasoning (default)
thinking off             Faster responses, no chain-of-thought
```

---

## Agentic Workflows (12 Built-in)

```bash
workflow run code-reviewer       Code review: quality, bugs, security
workflow run research-agent      Research + synthesis from knowledge
workflow run bug-hunter          Systematic bug finding + fixes
workflow run data-pipeline       Data processing + ETL pipeline
workflow run parallel-comparator Multi-model comparison (parallel)
workflow run api-doc-generator   API documentation generation
workflow run security-auditor    Security audit + vulnerability report
workflow run deploy-validator    Pre-deploy checklist + validation
workflow run content-factory     Content creation pipeline
workflow run log-analyzer        Log analysis + anomaly detection
workflow run test-generator      Unit + integration test generation
workflow run competitive-intel   Competitive landscape analysis
```

---

## AutoResearch Loop

Autonomous Karpathy-style hypothesis-driven research:

1. **Propose** — Generate a hypothesis to solve the goal
2. **Implement** — Execute the approach with real AI
3. **Evaluate** — Score the result (0.0–1.0)
4. **Decide** — Keep if score ≥ 0.6, discard otherwise
5. **Iterate** — Up to N iterations

Start: Research page in the UI, or `POST /research/runs`.

---

## WebSocket Message Protocol

```typescript
// Client → Agent
{ type: "input", data: "your command" }
{ type: "ping" }

// Agent → Client
{ type: "output", data: "...", isolateId?: "nano-abc123" }
{ type: "token",  data: "streaming chunk" }   // real token streaming
{ type: "system", data: "status message" }
{ type: "error",  data: "error text" }
{ type: "task_start",    taskId: "..." }
{ type: "task_complete", taskId: "...", timeMs: 342, tokens: 128 }
{ type: "pong" }
```

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, TypeScript |
| Terminal | xterm.js (@xterm/xterm), FitAddon, WebLinksAddon |
| UI | Tailwind CSS, shadcn/ui, Framer Motion |
| State | TanStack Query v5, Wouter (routing) |
| API Client | Auto-generated from OpenAPI spec |
| Backend | Node.js, Express, ws (WebSocket), TypeScript |
| Database | PostgreSQL + Drizzle ORM |
| AI Routing | OpenAI SDK (11 providers) + Anthropic SDK |
| CF Backend | Cloudflare Workers, Durable Objects, Workers AI |
| CF Framework | Hono, Cloudflare Agents SDK |
| CF Storage | D1 (SQLite), Dynamic Workers (LOADER) |
| Billing | Stripe |

---

## Key Design Decisions

**Why zero simulation?** The original codebase had 500 lines of hardcoded fake responses. These were completely deleted — every command now routes through a real AI model, making the platform genuinely useful rather than demonstrative.

**Why three agent classes?** Different cost/quality trade-offs. NanoClaw at 1024 tokens costs ~10x less than NemoClaw at 16384 tokens. Use NanoClaw for quick tasks, NemoClaw for complex analysis.

**Why the Mirror pattern?** Local Node.js and Cloudflare DO implement the same WebSocket protocol. The frontend can't tell the difference — same URL format, same JSON messages. This lets you develop locally with real AI and deploy to CF with zero frontend changes.

**Why WebSocket over HTTP?** Real token streaming (tokens appear as they're generated), multi-connection support (multiple tabs on same session), heartbeat detection, and real-time isolate status updates.
